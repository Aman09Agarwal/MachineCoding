package main.enums;

public enum VehicleType {
    CAR,
    BIKE,
    VAN,
    BUS
}
