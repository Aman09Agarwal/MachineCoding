package main.command;

public interface CommandExecutorService {
    void execute(String command);
}
