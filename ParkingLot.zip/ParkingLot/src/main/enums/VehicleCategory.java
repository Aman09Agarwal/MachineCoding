package main.enums;

public enum VehicleCategory {
    TWO_WHEELER,
    HATCHBACK,
    SEDAN,
    SUV,
    BUS
}
