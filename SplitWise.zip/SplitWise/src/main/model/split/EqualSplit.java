package main.model.split;

import main.model.User;

public class EqualSplit extends Split{
    public EqualSplit(User borrower) {
        super(borrower);
    }
}
