package main.model.expense;

public class ExpenseDetails {
    String details;

    public ExpenseDetails(String details) {
        this.details = details;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }
}
