package main.enums;

public enum ExpenseType {
    EQUAL, EXACT, PERCENT;
}
