package main.enums;

public enum InstructionType {
    EXPENSE, SHOW, QUIT;
}
